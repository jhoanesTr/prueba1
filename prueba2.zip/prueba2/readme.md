Crear carpeta para la aplicacion:
```shell
python manage.py startapp app
```

Añadimos la aplicacion que acabamos de crear:
```
#Ruta
prueba2/prueba2/setings.py

#Añado
INSTALLED_APPS[
    'app'
]
```

