from django.shortcuts import render

# Importando el CRUD
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView

# Llamamos al modelo Persona
from .models import Persona

# Mensajes para class-based views
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin

# Formularios en Django
from django.forms import Form

# Redireccionar
from django.urls import reverse


# Create your views here.
def index(request):
    return render(request, 'pages/index.html')


# Persona
class PersonaList(ListView):
    model = Persona


class PersonaCreate(SuccessMessageMixin, CreateView):
    model = Persona
    Form = Persona
    fields = "__all__"  # Muestra todos los campos de la tabla
    success_message = 'Persona creada correctamente!'


    # Redireccionar
    def get_success_url(self):
        return reverse('personas')


class PersonaView(DetailView):
    model = Persona


class PersonaUpdate(SuccessMessageMixin, UpdateView):
    model = Persona
    Form = Persona
    fields = "__all__"
    success_message = 'Persona actualizada correctamente!'

    def get_success_url(self):
        return reverse('personas')


class PersonaDelete(SuccessMessageMixin, DeleteView):
    model = Persona
    Form = Persona
    fields = "__all__"

    def get_success_url(self):
        success_message = 'Eliminado correctamente!'
        messages.success(self.request, success_message)
        return reverse('personas')
