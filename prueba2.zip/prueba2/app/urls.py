from django.urls import path
from . import views
from .views import PersonaList, PersonaView, PersonaCreate, PersonaUpdate, PersonaDelete

urlpatterns = [
    path('', views.index, name='index'),

    # Personas
    path('personas', PersonaList.as_view(template_name="pages/personas/index.html"), name='personas'),
    path('personas/ver/<int:pk>', PersonaView.as_view(template_name="pages/personas/ver.html"), name='personas/ver'),
    path('personas/crear', PersonaCreate.as_view(template_name="pages/personas/crear.html"), name='personas/crear'),
    path('personas/editar/<int:pk>', PersonaUpdate.as_view(template_name="pages/personas/editar.html"), name='personas/editar'),
    path('personas/eliminar/<int:pk>', PersonaDelete.as_view(), name='personas/eliminar')
]