from django.db import models


# Create your models here.
class Persona(models.Model):
    Nombre = models.CharField(max_length=50)
    Apellido1 = models.CharField(max_length=50)
    Apellido2 = models.CharField(max_length=50, blank=True)
    DNI = models.CharField(max_length=9)

    # Mes/Dia/Año
    Nacimiento = models.DateField(auto_now=False, auto_now_add=False)

    SEXO_TYPE = (
        ('Masculino', 'Masculino'),
        ('Femenino', 'Femenino'),
        ('No definido', 'No definido'),
    )
    Sexo = models.CharField(max_length=11, choices=SEXO_TYPE)

    CP = models.CharField(max_length=5)
    Telefono = models.CharField(max_length=15)
    Email = models.CharField(max_length=70)

